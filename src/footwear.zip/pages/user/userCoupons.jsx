import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { ShoppingCart, Heart, Ticket, MessageSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const navigate = useNavigate();

  return (
    <div className="w-64 bg-black min-h-screen text-white flex flex-col items-center py-10">
      <div className="flex flex-col items-center mb-10">
        <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-2xl font-bold">
          JD
        </div>
        <h2 className="text-lg font-semibold mt-3">Jane Doe</h2>
        <p className="text-sm text-gray-400">Welcome back!</p>
      </div>

      <div className="w-full space-y-4 px-6">
        <button
          onClick={() => navigate("/userOrders")}
          className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-gray-700 transition"
        >
          <ShoppingCart /> <span className="font-semibold">Orders</span>
        </button>
        <button
          onClick={() => navigate("/userWishlist")}
          className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-gray-700 transition"
        >
          <Heart /> <span className="font-semibold">Wishlist</span>
        </button>
        <button
          onClick={() => navigate("/userCoupons")}
          className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-gray-700 transition"
        >
          <Ticket /> <span className="font-semibold">Coupons</span>
        </button>
        <button
          onClick={() => navigate("/userReview")}
          className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-gray-700 transition"
        >
          <MessageSquare /> <span className="font-semibold">Reviews</span>
        </button>
      </div>
    </div>
  );
};

const CouponPage = () => {
  const today = new Date();
  const [searchTerm, setSearchTerm] = useState("");
  const [fetchedCoupons, setFetchedCoupons] = useState([]);
  const [claimedCoupons, setClaimedCoupons] = useState([]);
  const [popup, setPopup] = useState(null);

  // ✅ Simulate dynamic fetch
  useEffect(() => {
    // Example: You could replace this with a real API call using fetch/axios
    const fetchCoupons = async () => {
      const dynamicCoupons = [
        {
          id: 1,
          title: "Flat 20% Off",
          code: "SAVE20",
          expiry: "2025-10-01",
          terms:
            "Applicable on minimum purchase of $50. Cannot be clubbed with other offers.",
        },
        {
          id: 2,
          title: "Free Shipping",
          code: "FREESHIP",
          expiry: "2025-08-15",
          terms:
            "Valid only on orders above $25. Not applicable on international shipping.",
        },
        {
          id: 3,
          title: "Buy 1 Get 1 Free",
          code: "BOGO",
          expiry: "2025-12-31",
          terms:
            "Applicable only on selected categories. Free item must be of equal or lesser value.",
        },
      ];

      // simulate network delay
      setTimeout(() => setFetchedCoupons(dynamicCoupons), 500);
    };

    fetchCoupons();
  }, []);

  const filteredCoupons = fetchedCoupons.filter(
    (coupon) =>
      coupon.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coupon.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleClaim = (coupon) => {
    if (!claimedCoupons.includes(coupon.id)) {
      setClaimedCoupons([...claimedCoupons, coupon.id]);
      setPopup(`${coupon.title} claimed successfully!`);
      setTimeout(() => setPopup(null), 3000);
    }
  };

  return (
    <div className="flex w-full h-screen bg-[#fdf6e3] overflow-hidden">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center p-10 relative overflow-y-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-8 w-full max-w-5xl">
          Coupons
        </h1>

        <div className="w-full max-w-5xl text-black mb-6">
          <input
            type="text"
            placeholder="Search coupons by title or code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 border rounded-xl shadow-sm"
          />
        </div>

        {popup && (
          <div className="fixed top-5 right-5 bg-green-500 text-white px-4 py-2 rounded-xl shadow-lg animate-bounce z-50">
            {popup}
          </div>
        )}

        <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCoupons.length > 0 ? (
            filteredCoupons.map((coupon) => {
              const isExpired = new Date(coupon.expiry) < today;
              const isClaimed = claimedCoupons.includes(coupon.id);

              return (
                <div
                  key={coupon.id}
                  className={`p-6 shadow-md rounded-2xl transition-all duration-300 border ${
                    isExpired ? "opacity-50 grayscale" : "bg-white"
                  }`}
                >
                  <h2 className="text-xl font-bold mb-2">{coupon.title}</h2>
                  <p className="text-gray-600 mb-2">
                    Code:{" "}
                    <span className="font-mono bg-gray-200 px-2 py-1 rounded">
                      {coupon.code}
                    </span>
                  </p>
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-white text-sm ${
                      isExpired ? "bg-red-500" : "bg-green-500"
                    }`}
                  >
                    {isExpired
                      ? "Expired"
                      : `Valid until ${format(
                          new Date(coupon.expiry),
                          "dd MMM yyyy"
                        )}`}
                  </span>
                  <div className="mt-4">
                    <h3 className="font-semibold text-gray-700 mb-1">
                      Terms & Conditions
                    </h3>
                    <p className="text-sm text-gray-500">{coupon.terms}</p>
                  </div>
                  {!isExpired && !isClaimed && (
                    <div className="mt-4">
                      <button
                        onClick={() => handleClaim(coupon)}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-2 font-semibold"
                      >
                        Claim Now
                      </button>
                    </div>
                  )}
                  {isClaimed && !isExpired && (
                    <p className="mt-4 text-green-600 font-semibold">
                      Coupon Claimed!
                    </p>
                  )}
                </div>
              );
            })
          ) : (
            <p className="text-gray-500 text-center col-span-3">
              {fetchedCoupons.length === 0 ? "Loading coupons..." : "No coupons found."}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default CouponPage;
