import React, { useState } from "react";
import { ShoppingCart, Heart, Ticket, MessageSquare, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

export default function UserOrdersPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [showProductModal, setShowProductModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const orders = [
    {
      id: 1,
      name: "Nike Air Max 270",
      image: "/public/crocs1.jpg",
      price: 4500,
      color: "Black",
      size: "42",
      description: "The Nike Air Max 270 delivers visible cushioning for comfort all day long.",
      status: "Shipped",
    },
    {
      id: 2,
      name: "Adidas Ultraboost",
      image: "https://via.placeholder.com/150",
      price: 5800,
      color: "White",
      size: "43",
      description: "Experience superior energy return with the Adidas Ultraboost running shoes.",
      status: "Delivered",
    },
  ];

  const buttonClass = (path) =>
    `flex items-center gap-3 w-full py-3 px-4 rounded-lg transition ${
      location.pathname === path ? "bg-[#374151]" : "bg-[#111827] hover:bg-[#374151]"
    }`;

  return (
    <div className="flex w-screen min-h-screen bg-gradient-to-br from-[#FFF8E1] to-[#FFE0B2] overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 bg-black h-screen text-white flex flex-col items-center py-10 sticky top-0">
        <div className="flex flex-col items-center mb-10">
          <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-2xl font-bold">
            JD
          </div>
          <h2 className="text-lg font-semibold mt-3">Jane Doe</h2>
          <p className="text-sm text-gray-400">Welcome back!</p>
        </div>

        <div className="w-full space-y-4 px-6">
          <button onClick={() => navigate("/userOrders")} className={buttonClass("/userOrders")}>
            <ShoppingCart /> <span className="font-semibold">Orders</span>
          </button>
          <button onClick={() => navigate("/userWishlist")} className={buttonClass("/userWishlist")}>
            <Heart /> <span className="font-semibold">Wishlist</span>
          </button>
          <button onClick={() => navigate("/userCoupons")} className={buttonClass("/userCoupons")}>
            <Ticket /> <span className="font-semibold">Coupons</span>
          </button>
          <button onClick={() => navigate("/userReview")} className={buttonClass("/userReview")}>
            <MessageSquare /> <span className="font-semibold">Reviews</span>
          </button>
        </div>
      </div>

      {/* Orders Section */}
      <div className="flex-1 flex flex-col items-center p-10 overflow-y-auto">
        <div className="w-full max-w-6xl bg-white shadow-xl rounded-2xl p-8">
          <h1 className="text-3xl font-bold text-black mb-8">Your Orders</h1>
          {orders.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                setSelectedProduct(item);
                setShowProductModal(true);
              }}
              className="flex flex-col md:flex-row items-center justify-between border-b py-6 cursor-pointer hover:bg-gray-50 rounded-xl transition"
            >
              <div className="flex items-center gap-6">
                <img src={item.image} alt={item.name} className="w-28 h-28 rounded-xl border" />
                <div>
                  <h3 className="text-xl text-black font-semibold">{item.name}</h3>
                  <p className="text-gray-500">Size: {item.size}</p>
                  <p className="text-gray-500">Color: {item.color}</p>
                  <p className="text-gray-700 font-bold">₹{item.price}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-4 mt-4 md:mt-0">
                <span className="px-4 py-2 bg-green-100 text-green-700 font-medium rounded-lg">
                  {item.status}
                </span>
                <button
                  onClick={(e) => e.stopPropagation()}
                  className="bg-black hover:bg-gray-800 text-white font-semibold py-2 px-6 rounded-lg"
                >
                  Cancel Item
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product Details Popup */}
      {showProductModal && selectedProduct && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-60 z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full relative">
            <button onClick={() => setShowProductModal(false)} className="absolute top-3 right-3 text-gray-600 hover:text-black">
              <X />
            </button>
            <div className="flex flex-col items-center">
              <img src={selectedProduct.image} alt={selectedProduct.name} className="w-40 h-40 rounded-xl border mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">{selectedProduct.name}</h2>
              <p className="text-gray-500 mb-2">Size: {selectedProduct.size}</p>
              <p className="text-gray-500 mb-2">Color: {selectedProduct.color}</p>
              <p className="text-gray-700 font-bold mb-2">₹{selectedProduct.price}</p>
              <p className="text-gray-600 text-center mb-4">{selectedProduct.description}</p>
              <span className="px-4 py-2 bg-green-100 text-green-700 font-medium rounded-lg mb-2">
                {selectedProduct.status}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
