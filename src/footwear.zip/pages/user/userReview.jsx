import React, { useState } from "react";
import { ShoppingCart, Heart, Ticket, MessageSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const navigate = useNavigate();

  return (
    <div className="w-64 bg-black min-h-screen text-white flex flex-col items-center py-10">
      {/* Profile Section */}
      <div className="flex flex-col items-center mb-10">
        <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-2xl font-bold">
          JD
        </div>
        <h2 className="text-lg font-semibold mt-3">Jane Doe</h2>
        <p className="text-sm text-gray-400">Welcome back!</p>
      </div>

      {/* Menu Items */}
      <div className="w-full space-y-4 px-6">
        <button onClick={() => navigate('/userOrders')} className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-[#374151] transition">
          <ShoppingCart /> <span className="font-semibold">Orders</span>
        </button>
        <button onClick={() => navigate('/userWishlist')} className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-[#374151] transition">
          <Heart /> <span className="font-semibold">Wishlist</span>
        </button>
        <button onClick={() => navigate('/userCoupons')} className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-[#374151] transition">
          <Ticket /> <span className="font-semibold">Coupons</span>
        </button>
        <button onClick={() => navigate('/userReview')} className="flex items-center gap-3 w-full py-3 px-4 bg-[#111827] rounded-lg hover:bg-[#374151] transition">
          <MessageSquare /> <span className="font-semibold">Reviews</span>
        </button>
      </div>
    </div>
  );
};

const MyReviewsPage = () => {
  const [reviews, setReviews] = useState([
    {
      id: 1,
      product: {
        name: "Urban Style Sneakers",
        image: "https://placehold.co/120x120/E8E8E8/333333?text=Sneakers",
      },
      review: "Great quality and very comfortable for all-day wear!",
      rating: 5,
      date: "2025-09-15",
    },
    {
      id: 2,
      product: {
        name: "Trail Runner Hiking Boots",
        image: "https://placehold.co/120x120/E8E8E8/333333?text=Hiking+Boots",
      },
      review:
        "Fantastic grip and support, perfect for my weekend hikes. They were a bit stiff at first, but broke in nicely.",
      rating: 4,
      date: "2025-09-10",
    },
    {
      id: 3,
      product: {
        name: "Classic Leather Loafers",
        image: "public/sneakers1.jpg",
      },
      review:
        "These loafers are very stylish and comfortable. The leather is high quality and looks great.",
      rating: 5,
      date: "2025-08-28",
    },
    {
      id: 4,
      product: {
        name: "Everyday Canvas Flats",
        image: "https://placehold.co/120x120/E8E8E8/333333?text=Canvas+Flats",
      },
      review:
        "They are a good pair of shoes for a quick errand, but the sole is a bit thin.",
      rating: 3,
      date: "2025-08-20",
    },
    {
      id: 5,
      product: {
        name: "Performance Running Shoes",
        image: "https://placehold.co/120x120/E8E8E8/333333?text=Running+Shoes",
      },
      review:
        "Excellent cushioning and very lightweight. My new favorite shoes for long runs!",
      rating: 5,
      date: "2025-08-15",
    },
  ]);

  const [selectedReview, setSelectedReview] = useState(null);
  const [showDeleteMessage, setShowDeleteMessage] = useState(false);

  const CustomMessageModal = ({ message, onClose }) => (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white rounded-xl shadow-2xl p-6 md:p-8 w-full max-w-sm text-center">
        <p className="text-gray-700 font-medium mb-6 text-lg">{message}</p>
        <button
          onClick={onClose}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
        >
          OK
        </button>
      </div>
    </div>
  );

  const handleDelete = (id) => {
    setReviews(reviews.filter((review) => review.id !== id));
    setShowDeleteMessage(true);
  };

  return (
    <div className="flex w-full min-h-screen bg-[#fdf6e3]">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex justify-center py-12 px-4 md:px-8">
        <div className="w-full max-w-7xl bg-white shadow-2xl rounded-3xl p-6 md:p-12">
          <h1 className="text-4xl font-extrabold text-gray-800 mb-10 text-center">
            My Reviews
          </h1>

          {reviews.length > 0 ? (
            <div className="space-y-8">
              {reviews.map((review) => (
                <div
                  key={review.id}
                  className="flex flex-col md:flex-row items-start md:items-center gap-6 border-b border-gray-200 pb-8 cursor-pointer hover:bg-gray-100 transition-colors duration-200 rounded-xl p-4 md:p-6"
                  onClick={() => setSelectedReview(review)}
                >
                  <img
                    src={review.product.image}
                    alt={review.product.name}
                    className="w-28 h-28 md:w-32 md:h-32 rounded-2xl object-cover shadow-md"
                  />
                  <div className="flex-1">
                    <h2 className="text-2xl font-semibold text-gray-800">
                      {review.product.name}
                    </h2>
                    <p className="text-gray-600 mt-2 line-clamp-2 md:line-clamp-none">
                      {review.review}
                    </p>
                    <div className="flex items-center mt-3">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <span key={i} className="text-yellow-400 text-2xl">
                          ★
                        </span>
                      ))}
                      {Array.from({ length: 5 - review.rating }).map((_, i) => (
                        <span key={i} className="text-gray-300 text-2xl">
                          ★
                        </span>
                      ))}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Reviewed on {review.date}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(review.id);
                    }}
                    className="mt-4 md:mt-0 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-base shadow-lg transition-transform transform hover:scale-105"
                  >
                    Delete Review
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 text-lg mt-12">
              You haven’t written any reviews yet.
            </p>
          )}
        </div>
      </div>

      {/* Review Details Popup */}
      {selectedReview && (
        <div className="fixed inset-0 flex items-center justify-center p-4 bg-black bg-opacity-60 z-50 transition-opacity duration-300">
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 w-full max-w-xl text-center">
            <h2 className="text-3xl font-extrabold text-gray-800 mb-4">
              {selectedReview.product.name}
            </h2>
            <img
              src={selectedReview.product.image}
              alt={selectedReview.product.name}
              className="w-48 h-48 rounded-2xl object-cover shadow-lg mb-6 mx-auto"
            />
            <p className="text-gray-700 mb-6 text-lg">{selectedReview.review}</p>
            <div className="flex items-center justify-center mb-4">
              {Array.from({ length: selectedReview.rating }).map((_, i) => (
                <span key={i} className="text-yellow-400 text-3xl">★</span>
              ))}
              {Array.from({ length: 5 - selectedReview.rating }).map((_, i) => (
                <span key={i} className="text-gray-300 text-3xl">★</span>
              ))}
            </div>
            <p className="text-sm text-gray-500 text-center mb-8">
              Reviewed on {selectedReview.date}
            </p>
            <button
              onClick={() => setSelectedReview(null)}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-lg shadow-lg transition-transform transform hover:scale-105"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {showDeleteMessage && (
        <CustomMessageModal
          message="Review deleted successfully!"
          onClose={() => setShowDeleteMessage(false)}
        />
      )}
    </div>
  );
};

export default MyReviewsPage;
