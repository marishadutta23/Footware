import React, { useState } from "react";
import { ShoppingCart, User, Search, Filter, X } from "lucide-react";
import { BrowserRouter, useNavigate, useInRouterContext } from "react-router-dom"; 

const products = [
  { id: 1, name: "Men's Sneakers", category: "men", type: "sneakers", price: 80, image: "https://placehold.co/200x200/505050/FFFFFF?text=Sneakers", date: "2025-10-01" },
  { id: 2, name: "Women's Heels", category: "women", type: "heels", price: 120, image: "https://placehold.co/200x200/606060/FFFFFF?text=Heels", date: "2025-10-10" },
  { id: 3, name: "Crocs Unisex", category: "all", type: "crocs", price: 40, image: "https://placehold.co/200x200/707070/FFFFFF?text=Crocs", date: "2025-09-28" },
  { id: 4, name: "Men's Formal Shoes", category: "men", type: "shoes", price: 100, image: "https://placehold.co/200x200/808080/FFFFFF?text=Formal+Shoes", date: "2025-10-05" },
  { id: 5, name: "Women's Chappals", category: "women", type: "chappals", price: 30, image: "https://placehold.co/200x200/909090/FFFFFF?text=Chappals", date: "2025-09-20" },
  { id: 6, name: "Unisex Sneakers", category: "all", type: "sneakers", price: 70, image: "https://placehold.co/200x200/A0A0A0/FFFFFF?text=Unisex+Sneakers", date: "2025-10-08" },
];

// Custom Logo Component using Inline SVG
const ShoeverseLogo = () => (
  <div className="flex items-center space-x-2">
    {/* Recreated Logo Icon as SVG */}
    <svg width="32" height="32" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white">
      <path fillRule="evenodd" clipRule="evenodd" d="M 50 2 C 23.51 2 2 23.51 2 50 C 2 76.49 23.51 98 50 98 C 76.49 98 98 76.49 98 50 C 98 23.51 76.49 2 50 2 Z M 50 14 C 30.14 14 14 30.14 14 50 C 14 69.86 30.14 86 50 86 C 69.86 86 86 69.86 86 50 C 86 30.14 69.86 14 50 14 Z" fill="none" stroke="currentColor" strokeWidth="6"/>
      <path fillRule="evenodd" clipRule="evenodd" d="M 50 50 L 50 50 L 50 50 Z M 20 50 C 20 34.02 34.02 20 50 20 L 50 80 C 34.02 80 20 65.98 20 50 Z M 50 80 C 65.98 80 80 65.98 80 50 L 20 50 C 20 65.98 34.02 80 50 80 Z" fill="none" stroke="currentColor" strokeWidth="6"/>
      <path fillRule="evenodd" clipRule="evenodd" d="M 50 30 C 39.04 30 30 39.04 30 50 C 30 60.96 39.04 70 50 70 C 60.96 70 70 60.96 70 50 C 70 39.04 60.96 30 50 30 Z M 50 42 C 45.58 42 42 45.58 42 50 C 42 54.42 45.58 58 50 58 C 54.42 58 58 54.42 58 50 C 58 45.58 54.42 42 50 42 Z" fill="currentColor"/>
    </svg>
    {/* Brand Name and Tagline */}
    <div className="flex flex-col leading-none">
      <span className="text-xl sm:text-2xl font-bold tracking-widest uppercase">SHOEVERSE</span>
      <span className="text-xs sm:text-sm font-light tracking-wider mt-1">STEP INTO STYLE</span>
    </div>
  </div>
);

// Renaming the core logic component to ProductPageInner
function ProductPageInner() {
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [profileOpen, setProfileOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false); // New state for mobile filter modal
  
  const navigate = useNavigate();

  const filteredProducts = products
    .filter(
      (product) =>
        (filterCategory === "all" || product.category === filterCategory) &&
        (filterType === "all" || product.type === filterType)
    )
    .sort((a, b) => {
      if (sortBy === "low") return a.price - b.price;
      if (sortBy === "high") return b.price - a.price;
      if (sortBy === "newest") return new Date(b.date) - new Date(a.date);
      return 0;
    });

  const convertToRupees = (dollars) => {
    const rate = 83; // Example conversion rate: 1 USD ≈ 83 INR
    return `₹${(dollars * rate).toLocaleString("en-IN")}`;
  };
  
  const handleAddToCart = () => {
    navigate('/cart');
  };
  
  const handleViewCart = () => {
    navigate('/cart');
  };
  
  // Filter controls logic abstracted for reuse in sidebar and modal
  const FilterControls = ({ closeMenu }) => (
    <>
      <div className="mb-6">
        <h3 className="font-medium mb-3 text-gray-700 border-b border-gray-200 pb-1">Category</h3>
        <ul className="space-y-2 text-amber-50">
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterCategory === "all" && "font-bold text-gray-400"}`} onClick={() => {setFilterCategory("all"); closeMenu && closeMenu();}}>All</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterCategory === "men" && "font-bold text-gray-40000"}`} onClick={() => {setFilterCategory("men"); closeMenu && closeMenu();}}>Men</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterCategory === "women" && "font-bold text-gray-400"}`} onClick={() => {setFilterCategory("women"); closeMenu && closeMenu();}}>Women</button></li>
        </ul>
      </div>

      <div>
        <h3 className="font-medium mb-3 text-gray-700 border-b border-gray-200 pb-1">Type</h3>
        <ul className="space-y-2 text-amber-50">
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "all" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("all"); closeMenu && closeMenu();}}>All</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "sneakers" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("sneakers"); closeMenu && closeMenu();}}>Sneakers</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "heels" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("heels"); closeMenu && closeMenu();}}>Heels</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "crocs" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("crocs"); closeMenu && closeMenu();}}>Crocs</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "shoes" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("shoes"); closeMenu && closeMenu();}}>Shoes</button></li>
          <li><button className={`w-full text-left hover:text-blue-300 transition ${filterType === "chappals" && "font-bold text-gray-400"}`} onClick={() => {setFilterType("chappals"); closeMenu && closeMenu();}}>Chappals</button></li>
        </ul>
      </div>
    </>
  );


  return (
    <div className="min-h-screen w-screen bg-[#F7F2E6] text-gray-900">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-4 sm:px-8 py-4 bg-[#4A433B]/90 backdrop-blur-md shadow-lg sticky top-0 z-10 text-white">
        
        {/* Replaced old text with new Logo Component */}
        <ShoeverseLogo />
        
        

        <div className="flex items-center gap-4 sm:gap-6 relative">
          {/* Search Input for Navbar */}
          <div className="relative hidden sm:block">
            <input
              type="text"
              placeholder="Search..."
              className="px-4 py-2 rounded-full border border-gray-400 bg-gray-700 text-white placeholder-gray-300 outline-none text-sm w-40 md:w-56"
            />
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
          </div>
          
          {/* Cart Icon - ADDED onClick HANDLER */}
          <ShoppingCart 
            className="w-6 h-6 text-gray-300 cursor-pointer hover:text-gray-100 transition" 
            onClick={handleViewCart}
          />
          
          {/* Profile Dropdown */}
          <div className="relative">
            <User
              className="w-6 h-6 text-gray-300 cursor-pointer hover:text-gray-100 transition"
              onClick={() => setProfileOpen(!profileOpen)}
            />
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-gray-800 text-white border border-gray-700 rounded-lg shadow-lg text-sm z-20">
                <button onClick={() => navigate('/userOrders')} className="block w-full text-center px-4 py-2 hover:bg-gray-700">Dashboard</button>
                <button onClick={() => navigate('/profiles')} className="block w-full text-center px-4 py-2 hover:bg-gray-700">Profile</button>
                <button onClick={() => navigate('/logout')} className="block w-full text-center px-4 py-2 hover:bg-gray-700 text-red-400">Logout</button>
              </div>
            )}
          </div>
        </div>
      </nav>

      <div className="flex w-full">
        {/* Desktop Sidebar (Hidden on mobile) */}
        <div className="w-64 bg-white p-6 border-r border-gray-200 shadow-lg min-h-screen sticky top-[72px] hidden sm:block">
          <h2 className="text-xl font-bold mb-6 text-gray-900">Filter</h2>
          <FilterControls closeMenu={() => {}} />
        </div>

        {/* Products Grid */}
        <div className="flex-1 p-4 sm:p-8 text-gray-900">
          
          {/* Mobile Filter Button (Visible on mobile) */}
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Shop Our Latest Collection</h1>
            <button 
              onClick={() => setIsFilterModalOpen(true)}
              className="sm:hidden flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-full shadow-md transition"
            >
              <Filter size={18} />
              Filter
            </button>

            {/* Sort dropdown for mobile/tablet */}
            <div className="hidden sm:flex items-center gap-2">
              <label htmlFor="sort" className="text-sm font-medium text-gray-700">Sort By:</label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-gray-400 rounded-full bg-white text-gray-700 text-sm shadow-sm focus:outline-none"
              >
                <option value="newest">Newest</option>
                <option value="low">Price: Low to High</option>
                <option value="high">Price: High to Low</option>
              </select>
            </div>
          </div>
          
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white rounded-xl shadow-lg p-3 sm:p-4 hover:shadow-xl transition transform hover:scale-[1.02] duration-300">
                  <img src={product.image} alt={product.name} className="w-full h-24 sm:h-40 object-cover rounded-md mb-2 sm:mb-4 border border-gray-100" />
                  <h3 className="text-sm sm:text-lg font-bold mb-1">{product.name}</h3>
                  <p className="text-gray-700 font-semibold text-base sm:text-xl">{convertToRupees(product.price)}</p>
                  <button onClick={handleAddToCart} className="mt-2 sm:mt-4 w-full py-2 sm:py-3 bg-black hover:bg-gray-300 text-white rounded-full font-semibold text-sm transition shadow-md">
                    Add to Cart
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-700 text-xl">No products found matching your filter criteria.</p>
          )}
        </div>
      </div>
      
      {/* Mobile Filter Modal */}
      {isFilterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="relative bg-white rounded-xl w-full max-w-sm p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-6 border-b pb-3">
              <h2 className="text-2xl font-bold text-gray-900">Filter Products</h2>
              <button
                onClick={() => setIsFilterModalOpen(false)}
                className="p-2 rounded-full text-gray-600 hover:bg-gray-100 transition"
              >
                <X size={24} />
              </button>
            </div>
            {/* Reusable Filter Controls, passing the close function */}
            <FilterControls closeMenu={() => setIsFilterModalOpen(false)} />
          </div>
        </div>
      )}

    </div>
  );
}

// Wrapper component to provide Router context in the Canvas environment
export default function ProductPage() {
  const inRouter = useInRouterContext();
  if (inRouter) {
    return <ProductPageInner />;
  }

  return (
    <BrowserRouter>
      <ProductPageInner />
    </BrowserRouter>
  );
}
