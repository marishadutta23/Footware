import React, { useState } from "react";
import { ShoppingCart, X, ArrowLeft, FileText, HelpCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function CartPage() {
  const navigate = useNavigate();
  const [showHelp, setShowHelp] = useState(false);

  const cartItems = [
    { id: 1, title: "Nike Air Max", category: "Men's Sneakers", price: 4500, image: "https://via.placeholder.com/150" },
    { id: 2, title: "Adidas Ultraboost", category: "Women's Sneakers", price: 5999, image: "https://via.placeholder.com/150" },
    { id: 3, title: "Puma Running Shoes", category: "Unisex Sports", price: 3999, image: "https://via.placeholder.com/150" },
    { id: 4, title: "Crocs Classic", category: "Unisex Casual", price: 2999, image: "https://via.placeholder.com/150" },
  ];

  const total = cartItems.reduce((acc, item) => acc + item.price, 0);
  const discount = total * 0.1;
  const tax = (total - discount) * 0.05;
  const shipping = 199;
  const finalTotal = total - discount + tax + shipping;

  const handleCheckout = (opts = {}) => {
    if (opts.singleItemId) {
      navigate(`/payment?item=${opts.singleItemId}`);
    } else {
      navigate("/payment");
    }
  };

  const handleBuyNow = (id) => {
    handleCheckout({ singleItemId: id });
  };

  const handleBack = () => {
    navigate("/home");
  };

  return (
    <div className="min-h-screen w-screen font-sans bg-[#F5F5DC] text-[#333] flex flex-col items-center p-10 overflow-y-auto">
      <div className="relative w-full max-w-6xl mb-10 flex items-center justify-center">
        <button
          onClick={handleBack}
          className="absolute left-0 flex items-center gap-2 text-lg font-medium bg-[#8B4513] text-white px-4 py-2 rounded-lg hover:bg-[#A0522D] transition"
        >
          <ArrowLeft className="w-5 h-5" /> Back
        </button>

        <div className="flex items-center gap-2 text-4xl font-bold">
          <ShoppingCart className="text-[#8B4513] w-10 h-10" />
          Your Cart
        </div>

        <button
          onClick={() => setShowHelp(true)}
          className="absolute right-0 flex items-center gap-2 text-lg font-medium bg-[#8B4513] text-white px-4 py-2 rounded-lg hover:bg-[#A0522D] transition"
        >
          <HelpCircle className="w-5 h-5" /> Need Help
        </button>
      </div>

      {showHelp && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-2xl p-8 shadow-lg w-96 relative">
            <button
              onClick={() => setShowHelp(false)}
              className="absolute top-2 right-2 text-red-500 hover:text-red-700"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-2xl font-bold text-[#8B4513] mb-4">Need Help?</h2>
            <p className="text-gray-700 mb-4">
              For any queries, contact our customer support team at
              <br />
              <strong>support@shoestore.com</strong>
              <br />or call us at <strong>+91 98765 43210</strong>.
            </p>
            <form className="flex flex-col gap-3">
              <input
                type="text"
                placeholder="Your Name"
                className="border border-gray-300 rounded-lg px-3 py-2"
              />
              <textarea
                placeholder="Describe your issue..."
                className="border border-gray-300 rounded-lg px-3 py-2 h-24"
              ></textarea>
              <button
                type="button"
                onClick={() => setShowHelp(false)}
                className="bg-[#8B4513] hover:bg-[#A0522D] text-white px-4 py-2 rounded-lg w-full"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="w-full max-w-6xl flex flex-col gap-6 mb-8">
        {cartItems.map((item) => (
          <div
            key={item.id}
            className="bg-[#fffaf0] rounded-2xl shadow-md p-6 flex items-center justify-between gap-6 hover:shadow-xl transition"
          >
            <div className="flex items-center gap-6">
              <img src={item.image} alt={item.title} className="w-24 h-24 rounded-lg object-cover" />
              <div>
                <h2 className="font-bold text-2xl">{item.title}</h2>
                <p className="text-gray-600 text-base">{item.category}</p>
                <p className="text-[#8B4513] font-semibold text-lg">₹{item.price}</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => handleBuyNow(item.id)}
                className="bg-[#8B4513] hover:bg-[#A0522D] text-white px-6 py-3 rounded-lg font-medium text-lg transition"
              >
                Buy Now
              </button>
              <button className="p-3 hover:bg-red-100 rounded-lg transition">
                <X className="text-red-500 w-6 h-6" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="w-full max-w-6xl bg-[#fffaf0] rounded-2xl shadow-md p-8 mb-6 flex justify-between items-center">
        <div>
          <p className="text-xl font-semibold">Total Items: {cartItems.length}</p>
          <p className="text-2xl font-bold text-[#8B4513]">Total Price: ₹{total.toFixed(2)}</p>
        </div>
      </div>

      <div className="w-full max-w-6xl bg-[#fffaf0] rounded-2xl shadow-md p-8 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <FileText className="text-[#8B4513] w-6 h-6" />
          <h3 className="text-2xl font-bold text-[#8B4513]">Order Summary</h3>
        </div>
        <div className="text-lg space-y-2">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span>₹{total.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Discount (10%):</span>
            <span className="text-green-600">-₹{discount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Tax (5%):</span>
            <span>₹{tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Shipping:</span>
            <span>₹{shipping.toFixed(2)}</span>
          </div>
          <hr className="my-3 border-gray-300" />
          <div className="flex justify-between font-bold text-xl">
            <span>Final Total:</span>
            <span className="text-[#8B4513]">₹{finalTotal.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <button
        onClick={() => handleCheckout()}
        className="bg-[#8B4513] hover:bg-[#A0522D] text-white px-10 py-4 rounded-xl font-semibold text-xl transition w-full max-w-6xl"
      >
        Checkout All Items
      </button>
    </div>
  );
}