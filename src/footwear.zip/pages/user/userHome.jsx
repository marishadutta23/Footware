import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  ShoppingCart,
  Heart,
  User,
  Facebook,
  Instagram,
  Twitter,
} from "lucide-react";

const ShoeverseLogo = () => (
  <div className="flex items-center space-x-2">
    <svg
      width="32"
      height="32"
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="text-white"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M 50 2 C 23.51 2 2 23.51 2 50 C 2 76.49 23.51 98 50 98 C 76.49 98 98 76.49 98 50 C 98 23.51 76.49 2 50 2 Z M 50 14 C 30.14 14 14 30.14 14 50 C 14 69.86 30.14 86 50 86 C 69.86 86 86 69.86 86 50 C 86 30.14 69.86 14 50 14 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="6"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M 50 50 L 50 50 L 50 50 Z M 20 50 C 20 34.02 34.02 20 50 20 L 50 80 C 34.02 80 20 65.98 20 50 Z M 50 80 C 65.98 80 80 65.98 80 50 L 20 50 C 20 65.98 34.02 80 50 80 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="6"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M 50 30 C 39.04 30 30 39.04 30 50 C 30 60.96 39.04 70 50 70 C 60.96 70 70 60.96 70 50 C 70 39.04 60.96 30 50 30 Z M 50 42 C 45.58 42 42 45.58 42 50 C 42 54.42 45.58 58 50 58 C 54.42 58 58 54.42 58 50 C 58 45.58 54.42 42 50 42 Z"
        fill="currentColor"
      />
    </svg>
    <div className="flex flex-col leading-none">
      <span className="text-xl sm:text-2xl font-bold tracking-widest uppercase">
        SHOEVERSE
      </span>
      <span className="text-xs sm:text-sm font-light tracking-wider mt-1">
        STEP INTO STYLE
      </span>
    </div>
  </div>
);

export default function HomePage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  const slides = [
    { title: "Comfort Meets Style", subtitle: "Shoes That Define You", buttonText: "Shop Collection", img: "public/sneakers1.jpg" },
    { title: "Comfort Meets Style", subtitle: "Shoes That Define You", buttonText: "Shop Collection", img: "public/crocs1.jpg" },
    { title: "Comfort Meets Style", subtitle: "Shoes That Define You", buttonText: "Shop Collection", img: "public/heel2.jpg" },
    { title: "Comfort Meets Style", subtitle: "Shoes That Define You", buttonText: "Shop Collection", img: "public/sneakers2.jpeg" },
  ];

  const products = [
    { id: 1, name: "Classic Sneakers", price: "₹4,900", img: "sneakers1.jpg" },
    { id: 2, name: "Leather Boots", price: "₹9,900", img: "heel2.jpg" },
    { id: 3, name: "Running Shoes", price: "₹7,300", img: "crocs2.jpg" },
    { id: 4, name: "Casual Loafers", price: "₹6,100", img: "sneakers3.jpg" },
  ];

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);

  useEffect(() => {
    const timer = setInterval(nextSlide, 4000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative w-full min-h-screen bg-[#f5f5dc] flex flex-col">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 w-full flex items-center justify-between px-4 md:px-12 py-4 z-20 backdrop-blur-md bg-black/60 text-white shadow-lg border-b border-white/10 transition-all duration-300">
        <ShoeverseLogo />

        <button
          className="md:hidden text-white focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          ☰
        </button>

        <div className="hidden md:flex items-center space-x-6">
          <input
            type="text"
            placeholder="Search..."
            className="hidden sm:block px-4 py-2 rounded-full border border-gray-600 bg-gray-900/70 text-white placeholder-gray-400 outline-none backdrop-blur-sm"
          />
          <a href="productsPage" className="hover:text-gray-300">Products</a>
          <Heart className="cursor-pointer hover:text-red-400" />
          <ShoppingCart className="cursor-pointer hover:text-gray-300" />

          <div className="relative" ref={dropdownRef}>
            <div
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => setDropdownOpen(!dropdownOpen)}
            >
              <User />
              <span className="hidden md:inline">Profile</span>
            </div>
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-black/80 backdrop-blur-lg text-white rounded-lg shadow-lg overflow-hidden border border-white/10">
                <a href="userOrders" className="block px-4 py-2 hover:bg-white/10">Dashboard</a>
                <a href="Profiles" className="block px-4 py-2 hover:bg-white/10">Profile</a>
                <a href="logout" className="block px-4 py-2 hover:bg-white/10">Logout</a>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="w-full h-[80vh] relative overflow-hidden mt-16">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
            }`}
          >
            <img src={slide.img} alt={slide.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-center text-white px-4">
              <h2 className="text-3xl font-bold mb-4 animate-fadeInUp">{slide.title}</h2>
              <p className="text-lg mb-6 animate-fadeIn">{slide.subtitle}</p>
              <button
                onClick={() => navigate("/productsPage")}
                className="bg-black text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition transform hover:scale-105"
              >
                {slide.buttonText}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Product Showcase */}
      <section className="py-12 px-6 md:px-12 bg-[#f5f5dc] text-black">
        <h3 className="text-center text-3xl font-bold mb-8 animate-fadeIn">Featured Products</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-xl overflow-hidden shadow-lg hover:scale-105 transform transition duration-300 animate-fadeInUp"
            >
              <img src={product.img} alt={product.name} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h4 className="font-semibold text-lg mb-2">{product.name}</h4>
                <p className="text-gray-700 mb-4">{product.price}</p>
                <button
                  onClick={() => navigate("/cart")}
                  className="bg-black text-white px-4 py-2 rounded-lg font-semibold hover:bg-gray-800 w-full transition transform hover:scale-105"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-gray-300 py-8 px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Shoeverse</h4>
            <p>Your go-to destination for stylish and comfortable footwear.</p>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">Home</a></li>
              <li><a href="#" className="hover:text-white">Products</a></li>
              <li><a href="#" className="hover:text-white">About Us</a></li>
              <li><a href="#" className="hover:text-white">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-white"><Facebook /></a>
              <a href="#" className="hover:text-white"><Instagram /></a>
              <a href="#" className="hover:text-white"><Twitter /></a>
            </div>
          </div>
        </div>
        <div className="text-center text-sm text-gray-500 mt-8">
          © 2025 Shoeverse. All rights reserved.
        </div>
      </footer>

      <style jsx>{`
        .animate-fadeIn { animation: fadeIn 1s ease-in-out; }
        .animate-fadeInUp { animation: fadeInUp 1s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px);} to { opacity: 1; transform: translateY(0);} }
      `}</style>
    </div>
  );
}