import React, { useState, useEffect } from "react";
import {
  Edit,
  Trash2,
  Plus,
  LayoutDashboard,
  Package,
  ShoppingCart,
  Star,
  ChevronLeft,
  ChevronRight,
  User,
  TicketPercent,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Sidebar = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`bg-black text-white h-screen transition-all duration-300 ${
        collapsed ? "w-20" : "w-64"
      }`}
    >
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        {!collapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </button>
      </div>
      <nav className="mt-6 space-y-2">
        <a href="/dashboard" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <LayoutDashboard size={20} />
          {!collapsed && <span>Dashboard</span>}
        </a>
        <a href="/productsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <Package size={20} />
          {!collapsed && <span>Manage Products</span>}
        </a>
        <a href="/ordersManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <ShoppingCart size={20} />
          {!collapsed && <span>Orders</span>}
        </a>
        <a href="/customer" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <User size={20} />
          {!collapsed && <span>Customers</span>}
        </a>
        <a href="/couponsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <TicketPercent size={20} />
          {!collapsed && <span>Coupons</span>}
        </a>
        <a href="/reviewsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400">
          <Star size={20} />
          {!collapsed && <span>Reviews</span>}
        </a>
      </nav>
    </div>
  );
};

const ProductsManage = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const savedProducts = JSON.parse(localStorage.getItem("products")) || [];
    setProducts(savedProducts);
  }, []);

  const handleDelete = (id) => {
    const updated = products.filter((p) => p.id !== id);
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
  };

  const getStatus = (stock) => {
    if (stock === 0) return <span className="text-red-600 font-medium">Out of Stock</span>;
    if (stock <= 50) return <span className="text-yellow-600 font-medium">Few Left</span>;
    return <span className="text-green-600 font-medium">Available</span>;
  };

  return (
    <div className="flex w-screen h-screen overflow-hidden bg-[#fdf6e3]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      <div className="flex-1 h-screen bg-[#fdf6e3] p-6 overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-black">Product Management</h2>
          <button
            onClick={() => navigate("/addProducts")}
            className="bg-blue-600 text-white px-5 py-2 rounded-lg shadow hover:bg-blue-700 flex items-center gap-2"
          >
            <Plus size={18} /> Add New Product
          </button>
        </div>

        <div className="bg-white shadow rounded-lg overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-50 text-gray-600 text-sm">
              <tr>
                <th className="py-3 px-4 text-left">Image</th>
                <th className="py-3 px-4 text-left">Product Name</th>
                <th className="py-3 px-4">SKU</th>
                <th className="py-3 px-4">Price</th>
                <th className="py-3 px-4">Stock</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {products.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-6 text-gray-500">
                    No products available. Add one now!
                  </td>
                </tr>
              ) : (
                products.map((product) => (
                  <tr key={product.id} className="border-t hover:bg-gray-50">
                    <td className="py-3 px-4">
                      {product.image ? (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-md border"
                        />
                      ) : (
                        <div className="w-12 h-12 flex items-center justify-center bg-gray-200 rounded-md text-gray-600 font-medium">
                          N/A
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 font-medium">{product.name}</td>
                    <td className="py-3 px-4 text-center">{product.sku}</td>
                    <td className="py-3 px-4 text-center">₹{Number(product.price).toFixed(2)}</td>
                    <td className="py-3 px-4 text-center">{product.stock}</td>
                    <td className="py-3 px-4 text-center">{getStatus(product.stock)}</td>
                    <td className="py-3 px-4 flex gap-3 justify-center">
                      <button className="text-blue-500 hover:text-blue-700 flex items-center gap-1">
                        <Edit size={16} /> Edit
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="text-red-500 hover:text-red-700 flex items-center gap-1"
                      >
                        <Trash2 size={16} /> Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductsManage;