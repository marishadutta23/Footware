import React, { useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Users,
  ShoppingCart,
  Star,
  Package,
  Ticket,
  X,
} from "lucide-react";

// Sidebar Component
const Sidebar = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`bg-black text-white min-h-screen transition-all duration-300 fixed md:relative z-40 ${
        collapsed ? "w-20" : "w-72"
      }`}
    >
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        {!collapsed && <h2 className="text-2xl font-bold">Dashboard</h2>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </button>
      </div>
      <nav className="mt-6 space-y-2 text-lg">
        <a href="/dashboard" className="flex items-center gap-4 px-6 py-3 hover:bg-gray-800">
          <LayoutDashboard size={22} />
          {!collapsed && <span>Dashboard</span>}
        </a>
        <a href="/productsManage" className="flex items-center gap-4 px-6 py-3 hover:bg-gray-800">
          <Package size={22} />
          {!collapsed && <span>Manage Products</span>}
        </a>
        <a href="/ordersManage" className="flex items-center gap-4 px-6 py-3 hover:bg-gray-800">
          <ShoppingCart size={22} />
          {!collapsed && <span>Orders</span>}
        </a>
        <a href="/customer" className="flex items-center gap-4 px-6 py-3 hover:bg-gray-800">
          <Users size={22} />
          {!collapsed && <span>Customers</span>}
        </a>
        <a href="/couponsManage" className="flex items-center gap-4 px-6 py-3 hover:bg-gray-800">
          <Ticket size={22} />
          {!collapsed && <span>Coupons</span>}
        </a>
        <a href="/reviewsManage" className="flex items-center gap-4 px-6 py-3 bg-gray-900">
          <Star size={22} />
          {!collapsed && <span>Reviews</span>}
        </a>
      </nav>
    </div>
  );
};

// Review Page Component
const ReviewPage = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [selectedReview, setSelectedReview] = useState(null);

  const reviews = [
    {
      id: 1,
      name: "Jane Doe",
      product: "Running Shoes",
      rating: 4,
      feedback: "Great quality shoes! Very comfortable and light weight.",
      date: "2025-09-01",
      email: "jane@example.com",
    },
    {
      id: 2,
      name: "John Smith",
      product: "Leather Jacket",
      rating: 5,
      feedback: "Absolutely loved the jacket. Fits perfectly and looks stylish.",
      date: "2025-09-10",
      email: "john@example.com",
    },
    {
      id: 3,
      name: "Alice Brown",
      product: "Sports Watch",
      rating: 3,
      feedback: "Good watch but battery drains quickly.",
      date: "2025-09-12",
      email: "alice@example.com",
    },
  ];

  return (
    <div className="flex min-h-screen w-full bg-gradient-to-br from-amber-100 via-white to-amber-200">
      {/* Sidebar */}
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Main Content */}
      <div className="flex-1 text-black p-6 md:p-12 overflow-auto md:ml-0 ml-20 max-w-[1920px] mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold mb-8 md:mb-12">Customer Reviews</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6 md:gap-10">
          {reviews.map((review) => (
            <div
              key={review.id}
              onClick={() => setSelectedReview(review)}
              className="bg-white shadow-lg rounded-2xl p-6 md:p-8 cursor-pointer hover:shadow-2xl transition h-full"
            >
              <h3 className="font-semibold text-xl md:text-2xl mb-2 md:mb-3">{review.name}</h3>
              <p className="text-gray-600 text-base md:text-lg mb-1 md:mb-2">Product: {review.product}</p>
              <p className="text-yellow-500 text-base md:text-lg mb-2 md:mb-3">
                Rating: {"★".repeat(review.rating)}
                {"☆".repeat(5 - review.rating)}
              </p>
              <p className="text-gray-700 text-sm md:text-lg mb-3 md:mb-4 line-clamp-2">{review.feedback}</p>
              <p className="text-xs md:text-sm text-gray-500">{review.date}</p>
            </div>
          ))}
        </div>

        {/* Glass Popup Modal */}
        {selectedReview && (
          <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 px-4">
            <div className="relative bg-black/70 backdrop-blur-xl border border-white/30 shadow-2xl rounded-2xl p-6 md:p-10 w-full max-w-md md:max-w-4xl">
              {/* Close Button */}
              <button
                onClick={() => setSelectedReview(null)}
                className="absolute top-4 right-4 text-white hover:text-gray-300"
              >
                <X size={28} />
              </button>

              <h3 className="text-2xl md:text-4xl font-bold mb-4 text-white">{selectedReview.name}</h3>
              <p className="text-gray-200 text-base md:text-xl mb-2">Email: {selectedReview.email}</p>
              <p className="text-gray-200 text-base md:text-xl mb-2">Product: {selectedReview.product}</p>
              <p className="text-yellow-400 text-lg md:text-2xl mb-4">
                Rating: {"★".repeat(selectedReview.rating)}
                {"☆".repeat(5 - selectedReview.rating)}
              </p>
              <p className="text-white text-lg md:text-2xl mb-6">"{selectedReview.feedback}"</p>
              <p className="text-gray-300 text-sm md:text-lg">Reviewed on {selectedReview.date}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReviewPage;
