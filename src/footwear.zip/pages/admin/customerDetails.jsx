import React, { useState } from "react";
import { ChevronLeft, ChevronRight, LayoutDashboard, Users, ShoppingCart, Star, Package, Ticket } from "lucide-react";

const Sidebar = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`bg-black text-white min-h-screen transition-all duration-300 ${collapsed ? "w-20" : "w-64"}`}
    >
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        {!collapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </button>
      </div>
      <nav className="mt-6 space-y-2">
        <a href="/dashboard" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <LayoutDashboard size={20} />
          {!collapsed && <span>Dashboard</span>}
        </a>
        <a href="/productsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Package size={20} />
          {!collapsed && <span>Manage Products</span>}
        </a>
        <a href="/ordersManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <ShoppingCart size={20} />
          {!collapsed && <span>Orders</span>}
        </a>
        <a href="/customer" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Users size={20} />
          {!collapsed && <span>Customers</span>}
        </a>
        <a href="/couponsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Ticket size={20} />
          {!collapsed && <span>Coupons</span>}
        </a>
        <a href="/reviewsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Star size={20} />
          {!collapsed && <span>Reviews</span>}
        </a>
      </nav>
    </div>
  );
};

const CustomerDetails = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [customers, setCustomers] = useState([
    { id: 1, name: "Jane Doe", email: "jane@example.com", phone: "+91 9876543210", orders: 5, total: 12500, shipment: "Processing" },
    { id: 2, name: "John Smith", email: "john@example.com", phone: "+91 9123456780", orders: 2, total: 5600, shipment: "Shipped" },
    { id: 3, name: "Alice Brown", email: "alice@example.com", phone: "+91 9988776655", orders: 8, total: 21200, shipment: "Delivered" },
  ]);

  const handleShipmentChange = (id, status) => {
    setCustomers(
      customers.map((customer) =>
        customer.id === id ? { ...customer, shipment: status } : customer
      )
    );
  };

  return (
    <div className="flex min-h-screen w-screen bg-[#fdf6e3]">
      {/* Sidebar */}
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Main Content */}
      <div className="flex-1 bg-[#fdf6e3] p-10">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-4xl font-bold text-black">Customer Details</h2>
        </div>

        {/* Table */}
        <div className="bg-white shadow-lg rounded-lg overflow-x-auto">
          <table className="w-full border-collapse text-lg">
            <thead className="bg-gray-100 text-gray-700 uppercase tracking-wider">
              <tr>
                <th className="py-4 px-6 text-left">Customer ID</th>
                <th className="py-4 px-6 text-left">Name</th>
                <th className="py-4 px-6 text-left">Email</th>
                <th className="py-4 px-6 text-left">Phone</th>
                <th className="py-4 px-6 text-center">Orders</th>
                <th className="py-4 px-6 text-center">Total Spent (₹)</th>
                <th className="py-4 px-6 text-center">Shipment Status</th>
              </tr>
            </thead>
            <tbody className="text-gray-800">
              {customers.map((customer) => (
                <tr key={customer.id} className="border-t hover:bg-gray-50">
                  <td className="py-4 px-6">CUST-{customer.id.toString().padStart(3, "0")}</td>
                  <td className="py-4 px-6 font-semibold">{customer.name}</td>
                  <td className="py-4 px-6">{customer.email}</td>
                  <td className="py-4 px-6">{customer.phone}</td>
                  <td className="py-4 px-6 text-center">{customer.orders}</td>
                  <td className="py-4 px-6 text-center">₹{customer.total.toLocaleString()}</td>
                  <td className="py-4 px-6 text-center">
                    <select
                      value={customer.shipment}
                      onChange={(e) => handleShipmentChange(customer.id, e.target.value)}
                      className="border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Processing">Processing</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerDetails;
