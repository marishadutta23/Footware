import React, { useState } from "react";
import {
  Edit,
  Trash2,
  Plus,
  X,
  LayoutDashboard,
  Package,
  ShoppingCart,
  Star,
  ChevronLeft,
  ChevronRight,
  User,
  TicketPercent,
} from "lucide-react";

const Sidebar = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`bg-black text-white h-screen transition-all duration-300 ${
        collapsed ? "w-20" : "w-64"
      }`}
    >
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        {!collapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </button>
      </div>
      <nav className="mt-6 space-y-2">
        <a href="/dashboard" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <LayoutDashboard size={20} />
          {!collapsed && <span>Dashboard</span>}
        </a>
        <a href="/productsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Package size={20} />
          {!collapsed && <span>Manage Products</span>}
        </a>
        <a href="/ordersManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <ShoppingCart size={20} />
          {!collapsed && <span>Orders</span>}
        </a>
        <a href="/customer" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <User size={20} />
          {!collapsed && <span>Customers</span>}
        </a>
        <a href="/couponsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 bg-gray-900">
          <TicketPercent size={20} />
          {!collapsed && <span>Coupons</span>}
        </a>
        <a href="/reviewsManage" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800">
          <Star size={20} />
          {!collapsed && <span>Reviews</span>}
        </a>
      </nav>
    </div>
  );
};

const CouponsManage = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [coupons, setCoupons] = useState([
    { id: 1, code: "NEW50", discount: 50, expiry: "2025-12-31" },
    { id: 2, code: "WELCOME10", discount: 10, expiry: "2025-10-15" },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [editCoupon, setEditCoupon] = useState(null);
  const [formData, setFormData] = useState({ code: "", discount: "", expiry: "" });

  const handleDelete = (id) => setCoupons(coupons.filter((c) => c.id !== id));

  const handleAdd = () => {
    setEditCoupon(null);
    setFormData({ code: "", discount: "", expiry: "" });
    setShowForm(true);
  };

  const handleEdit = (coupon) => {
    setEditCoupon(coupon);
    setFormData(coupon);
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editCoupon) {
      setCoupons(coupons.map((c) => (c.id === editCoupon.id ? formData : c)));
    } else {
      setCoupons([...coupons, { ...formData, id: Date.now() }]);
    }
    setShowForm(false);
  };

  return (
    <div className="flex w-screen h-screen overflow-hidden bg-gradient-to-br from-amber-100 via-white to-amber-200">
      {/* Sidebar */}
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Main Content */}
      <div className="flex-1 h-screen p-6 overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-gray-900">Coupon Management</h2>
          <button
            onClick={handleAdd}
            className="bg-green-600 text-white px-5 py-2 rounded-lg shadow hover:bg-green-700 flex items-center gap-2"
          >
            <Plus size={18} /> Add New Coupon
          </button>
        </div>

        {/* Coupons Table */}
        <div className="bg-white shadow rounded-lg overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-50 text-gray-600 text-sm">
              <tr>
                <th className="py-3 px-4 text-center">Coupon Code</th>
                <th className="py-3 px-4 text-center">Discount (%)</th>
                <th className="py-3 px-4 text-center">Expiry Date</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {coupons.map((coupon) => (
                <tr key={coupon.id} className="border-t hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">{coupon.code}</td>
                  <td className="py-3 px-4 text-center">{coupon.discount}%</td>
                  <td className="py-3 px-4 text-center">{coupon.expiry}</td>
                  <td className="py-3 px-4 flex gap-3 justify-center">
                    <button
                      onClick={() => handleEdit(coupon)}
                      className="text-amber-50 hover:text-blue-300 flex items-center gap-1"
                    >
                      <Edit size={16} /> Edit
                    </button>
                    <button
                      onClick={() => handleDelete(coupon.id)}
                      className="text-amber-50 hover:text-red-500 flex items-center gap-1"
                    >
                      <Trash2 size={16} /> Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal for Add/Edit */}
        {showForm && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 p-4 z-50">
            <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
              <button
                onClick={() => setShowForm(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </button>
              <h2 className="text-xl font-bold mb-4 text-black">
                {editCoupon ? "Edit Coupon" : "Add New Coupon"}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="text"
                  placeholder="Coupon Code"
                  className="w-full border p-2 rounded text-black"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  required
                />
                <input
                  type="number"
                  placeholder="Discount %"
                  className="w-full border p-2 rounded text-black"
                  value={formData.discount}
                  onChange={(e) => setFormData({ ...formData, discount: parseInt(e.target.value) })}
                  required
                />
                <input
                  type="date"
                  className="w-full border p-2 rounded text-black"
                  value={formData.expiry}
                  onChange={(e) => setFormData({ ...formData, expiry: e.target.value })}
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
                >
                  {editCoupon ? "Update Coupon" : "Add Coupon"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CouponsManage;
