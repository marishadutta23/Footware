import React, { useState, useEffect } from "react";
import {
  LayoutDashboard,
  ChevronLeft,
  ChevronRight,
  Package,
  ShoppingCart,
  User,
  TicketPercent,
  Star,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Sidebar = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`bg-black text-white h-screen transition-all duration-300 ${
        collapsed ? "w-20" : "w-64"
      }`}
    >
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        {!collapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </button>
      </div>
      <nav className="mt-6 space-y-2">
        {[
          { path: "/dashboard", icon: <LayoutDashboard size={20} />, label: "Dashboard" },
          { path: "/productsManage", icon: <Package size={20} />, label: "Manage Products" },
          { path: "/ordersManage", icon: <ShoppingCart size={20} />, label: "Orders" },
          { path: "/customer", icon: <User size={20} />, label: "Customers" },
          { path: "/couponsManage", icon: <TicketPercent size={20} />, label: "Coupons" },
          { path: "/reviewsManage", icon: <Star size={20} />, label: "Reviews" },
        ].map((item, index) => (
          <a
            key={index}
            href={item.path}
            className="flex items-center gap-3 px-4 py-2 hover:bg-gray-800 text-indigo-400"
          >
            {item.icon}
            {!collapsed && <span>{item.label}</span>}
          </a>
        ))}
      </nav>
    </div>
  );
};

export default function AddProduct() {
  const [collapsed, setCollapsed] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    price: "",
    stock: "",
    status: "Available",
    image: null,
  });
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedData = localStorage.getItem("newProductData");
    if (savedData) setFormData(JSON.parse(savedData));
  }, []);

  useEffect(() => {
    localStorage.setItem("newProductData", JSON.stringify(formData));
  }, [formData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, image: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const products = JSON.parse(localStorage.getItem("products")) || [];

    const newProduct = {
      id: Date.now(),
      name: formData.name,
      sku: formData.sku,
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock),
      image: formData.image,
    };

    products.push(newProduct);
    localStorage.setItem("products", JSON.stringify(products));

    localStorage.removeItem("newProductData");

    setShowPopup(true);
  };

  const handleOk = () => {
    navigate("/productsManage");
  };

  const handleAddAgain = () => {
    setShowPopup(false);
    setFormData({
      name: "",
      sku: "",
      price: "",
      stock: "",
      status: "Available",
      image: null,
    });
  };

  return (
    <div className="flex min-h-screen text-black bg-[#FFF6E9] relative">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      <div className="flex-1 p-10">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Add New Product</h2>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white shadow-md rounded-2xl p-8 max-w-3xl"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {["name", "sku", "price", "stock"].map((field) => (
              <div key={field}>
                <label className="block text-sm font-medium mb-2 capitalize">
                  {field}
                </label>
                <input
                  type={field === "price" || field === "stock" ? "number" : "text"}
                  name={field}
                  value={formData[field]}
                  onChange={handleChange}
                  required
                  placeholder={`Enter ${field}`}
                  className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-purple-400"
                />
              </div>
            ))}

            <div>
              <label className="block text-sm font-medium mb-2">Status</label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-purple-400"
              >
                {["Available", "Few Left", "Out of Stock"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Upload Image</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-purple-400"
              />
              {formData.image && (
                <img
                  src={formData.image}
                  alt="Preview"
                  className="mt-3 w-24 h-24 object-cover rounded-lg border"
                />
              )}
            </div>
          </div>

          <div className="mt-8 flex justify-end">
            <button
              type="submit"
              className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800"
            >
              Add Product
            </button>
          </div>
        </form>
      </div>

      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 animate-fadeIn">
          <div className="bg-white p-6 rounded-xl shadow-lg text-center w-80">
            <h3 className="text-lg font-semibold mb-4">Product Added Successfully!</h3>
            <div className="flex justify-around">
              <button
                onClick={handleOk}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
              >
                OK
              </button>
              <button
                onClick={handleAddAgain}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                Add Again
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
