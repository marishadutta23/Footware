import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Star,
  ChevronLeft,
  ChevronRight,
  User,
  Ticket,
} from "lucide-react";

export default function OrderManagement() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [orders, setOrders] = useState([]);

  // Simulate fetching orders from an API
  useEffect(() => {
    const fetchOrders = async () => {
      // Simulated API response
      const data = [
        { id: "#ORD-001", date: "2023-10-26", customer: "Jane Doe", total: "₹120.00", status: "Processing" },
        { id: "#ORD-002", date: "2023-10-25", customer: "John Smith", total: "₹85.50", status: "Delivered" },
        { id: "#ORD-003", date: "2023-10-20", customer: "Alice Brown", total: "₹240.00", status: "Shipped" },
      ];
      setOrders(data);
    };
    fetchOrders();
  }, []);

  const updateStatus = (id, newStatus) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) =>
        order.id === id ? { ...order, status: newStatus } : order
      )
    );
  };

  return (
    <div className="flex w-screen h-screen bg-[#fdf6e3] overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-black text-white transition-all duration-300 flex flex-col`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          {sidebarOpen && <h2 className="text-lg font-bold">Dashboard</h2>}
          <button
            className="text-gray-300 bg-gray-900 p-1 rounded"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <ChevronLeft /> : <ChevronRight />}
          </button>
        </div>

        {/* Sidebar Navigation */}
        <nav className="flex-1 p-4 space-y-6">
          <a href="/dashboard" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <LayoutDashboard />
            {sidebarOpen && <span>Dashboard</span>}
          </a>
          <a href="/productsManage" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <Package />
            {sidebarOpen && <span>Manage Products</span>}
          </a>
          <a href="/ordersManage" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <ShoppingCart />
            {sidebarOpen && <span>Orders</span>}
          </a>
          <a href="/customer" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <User />
            {sidebarOpen && <span>Customers</span>}
          </a>
          <a href="/couponsManage" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <Ticket />
            {sidebarOpen && <span>Coupons</span>}
          </a>
          <a href="/reviewsManage" className="flex items-center space-x-3 text-blue-400 hover:text-blue-300">
            <Star />
            {sidebarOpen && <span>Reviews</span>}
          </a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 h-full bg-[#fdf6e3] p-10 flex flex-col">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Order Management</h2>
        </div>

        {/* Table Container */}
        <div className="bg-white shadow rounded-xl flex-1 overflow-auto">
          <table className="min-w-full text-left border-collapse">
            <thead className="sticky top-0 bg-gray-50">
              <tr className="text-gray-600 uppercase text-sm">
                <th className="px-6 py-3">Order ID</th>
                <th className="px-6 py-3">Date</th>
                <th className="px-6 py-3">Customer</th>
                <th className="px-6 py-3">Total</th>
                <th className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, idx) => (
                <tr key={idx} className="border-t hover:bg-gray-50">
                  <td className="px-6 py-4 text-gray-800 font-medium">{order.id}</td>
                  <td className="px-6 py-4 text-gray-600">{order.date}</td>
                  <td className="px-6 py-4 text-gray-600">{order.customer}</td>
                  <td className="px-6 py-4 text-gray-800">{order.total}</td>
                  <td className="px-6 py-4">
                    <select
                      value={order.status}
                      onChange={(e) => updateStatus(order.id, e.target.value)}
                      className="border rounded-lg px-3 py-1 focus:outline-none text-black focus:ring-2 focus:ring-blue-500"
                    >
                      <option>Processing</option>
                      <option>Shipped</option>
                      <option>Delivered</option>
                      <option>Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
